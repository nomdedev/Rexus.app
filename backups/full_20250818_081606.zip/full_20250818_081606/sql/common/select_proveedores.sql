SELECT DISTINCT proveedor FROM herrajes WHERE estado = 'ACTIVO' ORDER BY proveedor;
