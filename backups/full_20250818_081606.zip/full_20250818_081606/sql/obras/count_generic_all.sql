-- Query genérica para contar obras
SELECT COUNT(*) FROM [obras]
