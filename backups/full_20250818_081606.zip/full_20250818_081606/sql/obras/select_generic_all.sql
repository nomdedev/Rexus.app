-- Query genérica para obtener todas las obras
SELECT * FROM [obras]
