-- Este script es solo para datos demo, si se requiere
SELECT * FROM herrajes WHERE id IN (1,2);
