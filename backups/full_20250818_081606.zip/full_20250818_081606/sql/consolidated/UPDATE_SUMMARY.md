# SQL Script Update Summary

Generated: 2025-07-30 19:21:23

## Overview
- Total scripts processed: 17
- Successfully updated: 17
- Skipped (already consolidated): 0
- Failed: 0

## Updated Scripts
- buscar_herrajes.sql → buscar_herrajes.sql
- delete_herraje.sql → delete_herraje.sql
- insert_herraje.sql → insert_herraje.sql
- insert_herraje_obra.sql → insert_herraje_obra.sql
- insert_pedido_obra.sql → insert_pedido_obra.sql
- select_estadisticas_herrajes.sql → select_estadisticas_herrajes.sql
- select_herrajes.sql → select_herrajes.sql
- select_herrajes_por_obra.sql → select_herrajes_por_obra.sql
- select_herraje_demo.sql → select_herraje_demo.sql
- select_herraje_por_id.sql → select_herraje_por_id.sql
- select_inventario.sql → select_inventario.sql
- select_proveedores.sql → select_proveedores.sql
- select_vidrios.sql → select_vidrios.sql
- update_cantidad_pedida.sql → update_cantidad_pedida.sql
- update_herraje.sql → update_herraje.sql
- update_stock_herraje.sql → update_stock_herraje.sql
- create_tables.sql → create_tables.sql
