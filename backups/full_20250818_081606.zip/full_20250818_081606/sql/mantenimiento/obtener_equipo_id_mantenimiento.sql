SELECT equipo_id 
FROM mantenimientos 
WHERE id = ?
