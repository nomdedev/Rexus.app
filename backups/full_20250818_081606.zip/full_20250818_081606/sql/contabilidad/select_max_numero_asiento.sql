-- Obtiene el máximo número de asiento del libro contable
SELECT MAX(numero_asiento) FROM libro_contable