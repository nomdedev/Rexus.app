-- Obtiene el máximo número de recibo
SELECT MAX(numero_recibo) FROM recibos