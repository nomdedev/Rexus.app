-- Insertar nuevo departamento
-- Parámetros: codigo, nombre, descripcion, responsable, presupuesto_mensual, usuario_creacion, usuario_actualizacion
INSERT INTO [departamentos]
(codigo, nombre, descripcion, responsable, presupuesto_mensual, usuario_creacion, usuario_actualizacion)
VALUES (?, ?, ?, ?, ?, ?, ?)