-- Obtener presupuesto mensual de un departamento
-- Parámetros: departamento_id
SELECT presupuesto_mensual FROM departamentos WHERE id = ?