SELECT * FROM vidrios WHERE 1=1
-- Filtros dinámicos se agregan en el código usando parámetros seguros
