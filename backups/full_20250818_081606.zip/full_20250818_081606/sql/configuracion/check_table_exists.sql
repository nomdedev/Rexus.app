SELECT COUNT(*) FROM sysobjects WHERE name=? AND xtype='U';
