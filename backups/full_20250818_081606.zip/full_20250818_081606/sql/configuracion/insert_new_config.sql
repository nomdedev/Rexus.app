INSERT INTO configuracion (clave, valor, tipo, descripcion, fecha_creacion)
VALUES (?, ?, ?, ?, GETDATE())