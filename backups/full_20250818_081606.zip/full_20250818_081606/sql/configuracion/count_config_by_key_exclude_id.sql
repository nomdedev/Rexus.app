SELECT COUNT(*) FROM [configuracion_sistema] WHERE clave = ? AND id != ?;
