UPDATE configuracion
SET valor = ?
WHERE clave = ?