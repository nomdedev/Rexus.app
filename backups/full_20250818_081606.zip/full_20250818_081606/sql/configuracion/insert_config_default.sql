INSERT INTO [configuracion_sistema] (clave, valor, descripcion, tipo, categoria) VALUES (?, ?, ?, ?, ?);
