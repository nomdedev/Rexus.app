SELECT COUNT(*) FROM [configuracion_sistema];
