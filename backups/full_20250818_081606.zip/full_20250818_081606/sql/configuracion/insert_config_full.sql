INSERT INTO configuracion
(clave, valor, descripcion, tipo, categoria)
VALUES (?, ?, ?, ?, ?)