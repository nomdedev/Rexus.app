SELECT id, codigo, descripcion, tipo as categoria, acabado as subcategoria, stock, precio FROM inventario_perfiles WHERE 1=1
-- Filtros dinámicos se agregan en el código usando parámetros seguros
