-- Verificar existencia de tabla
SELECT * FROM sysobjects WHERE name=? AND xtype='U'