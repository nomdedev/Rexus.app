-- Obtener todas las compras básicas
SELECT * FROM compras