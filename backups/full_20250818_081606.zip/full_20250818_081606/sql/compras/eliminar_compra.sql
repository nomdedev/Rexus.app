-- Eliminar compra por ID
DELETE FROM compras WHERE id = ?