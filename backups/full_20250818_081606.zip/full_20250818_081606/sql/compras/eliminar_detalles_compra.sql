-- Eliminar detalles de una compra
DELETE FROM detalle_compras WHERE compra_id = ?