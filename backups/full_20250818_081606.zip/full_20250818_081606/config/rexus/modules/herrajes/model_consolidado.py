# DELETED: shim removed. File intentionally left as marker for removal.
raise ImportError("This shim was deleted. Install package editable and import via rexus.*")
