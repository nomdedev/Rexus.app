"""Modelo de Producción"""


class ProduccionModel:
    def __init__(self, db_connection=None):
        self.db_connection = db_connection
