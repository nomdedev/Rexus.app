"""
Submódulo de Recursos Humanos
"""

from .model import RecursosHumanosModel
from .controller import RecursosHumanosController

__all__ = ['RecursosHumanosModel', 'RecursosHumanosController']
