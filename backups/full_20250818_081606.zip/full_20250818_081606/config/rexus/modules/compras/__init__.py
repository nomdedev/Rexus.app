"""Módulo de Compras"""
from .view_complete import ComprasViewComplete as ComprasView

__all__ = ['ComprasView']
