"""
Módulo de Notificaciones - Rexus.app v2.0.0
"""
