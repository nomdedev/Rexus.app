Se han eliminado los shims de compatibilidad legacy `model_consolidado.py` para forzar el uso del paquete instalado en modo editable.

Archivos originalmente neutralizados y ahora eliminados:
- rexus/modules/inventario/model_consolidado.py
- rexus/modules/herrajes/model_consolidado.py
- rexus/modules/vidrios/model_consolidado.py
- rexus/modules/pedidos/model_consolidado.py
- rexus/modules/obras/model_consolidado.py

Si necesitas restaurar uno de ellos, usa el historial de git para recuperarlo.
