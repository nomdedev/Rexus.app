"""
Stock.app - Aplicación de Gestión de Inventario
Módulo principal de inicialización de la aplicación
"""

# Evitar import circular en inicialización
