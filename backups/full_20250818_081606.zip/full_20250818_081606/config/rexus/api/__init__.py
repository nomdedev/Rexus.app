# API REST para Rexus - Opcional
