# Inicialización del módulo core
